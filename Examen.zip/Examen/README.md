# Examen MF0491_3
# Fecha: 29/03/2022

## Parte práctica

```markdown
    Aplicación donde cada vez que se pulsa el botón, se incrementa un valor.
    Esta funcionalidad la he realizado mediante un archivo JavaScript, donde a partir de un Listener,
    se va incrementando de uno en uno el valor, cada vez que se pulsa el botón.
    En la hoja de estilos CSS he incluido una configuración flex-direction:column para posicionar los elementos en vertical y mediante el atributo line-height he distribuido los altos de un tercio y 2 tercios requeridos en el enunciado. Para centrar los elementos horizontalmente, utilicé el atributo
    text-align:center. 
```