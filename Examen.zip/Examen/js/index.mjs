//Selección del span #contador y el #boton
const contador = document.querySelector("#contador");
const boton = document.querySelector("#boton");

//Declaración e iniciación de la variable "valor" que llevará la cuenta de las pulsaciones dadas
let valor = 0;
/*
Listener mediante el cual cada vez que se haga click al botón,
se incremente la variable "valor" en uno y se muestre su valor por pantalla
*/
boton.addEventListener(
    "click",
    (event) => {
        valor++;
        contador.innerText = valor;
    }
);

